a = 5
b = True
c = 'hello'
d = 3.1415
print(a, b, c, d)
name = input('Введите ваше имя: ')
age = input('Введите ваш возраст: ')
city = input('Напишите ваш город: ')
print(f'Пользователь {name} из города {city} - возраст {age}')
