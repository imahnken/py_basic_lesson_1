import sys

a = ['hello', 15, True]
print(type(a))
print('id a: ', id(a))
print('The size of a:')
print(sys.getsizeof(a))

b = ('hello', 15, True)
print(type(b))
print('id b: ', id(b))
print('The size of b:')
print(sys.getsizeof(b))

c_our_first=15
print(type(c_our_first))
print('id c: ', id(c_our_first))
print('The size of c_our_first:')
print(sys.getsizeof(c_our_first))