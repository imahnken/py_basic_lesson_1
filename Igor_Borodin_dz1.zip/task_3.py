n = int(input('Введите целое число n от 0 до 9: '))
# result = n + n + n * 10 + n + n * 10 + n * 100
result = n * 3 + n * 20 + n * 100
print(f'Сумма чисел n + nn + nnn равна: {result}')
